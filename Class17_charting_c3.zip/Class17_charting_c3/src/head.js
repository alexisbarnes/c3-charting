(function (window) {
    'use strict';

    /*global define, module, exports, require */
